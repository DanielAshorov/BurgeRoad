import { CircularProgress, Modal } from "@mui/material";
import React from "react";
import BurgerIcon from "../../../burgerIcon.svg";
