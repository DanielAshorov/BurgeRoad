#!/bin/sh

npm rebuild esbuild

exec "$@"